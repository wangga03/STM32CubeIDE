/*
 * mainpp.h
 *
 *  Created on: Jan 6, 2024
 *      Author: HP GAMING
 */

#ifndef INC_MAINPP_H_
#define INC_MAINPP_H_

typedef struct{

	float bnoX;
	float bnoY;
	float bnoZ;

}ros_mag;

#ifdef __cplusplus
 extern "C" {
#endif

void setup(void);
void loop(void);
void rx_ros(float x, float y, float z);

#ifdef __cplusplus
}
#endif

#endif /* INC_MAINPP_H_ */
